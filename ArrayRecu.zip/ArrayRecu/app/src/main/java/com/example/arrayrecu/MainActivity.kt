package com.example.arrayrecu

import android.net.Uri
import androidx.navigation.NavController
import androidx.navigation.navArgument
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import com.example.arrayrecu.data.Datos
import com.example.arrayrecu.ui.theme.ArrayRecuTheme
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ArrayRecuTheme {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "list") {
                    composable("list") {
                        ItemList(navController)
                    }
                    composable(
                        "detail/{title}/{description}/{frase}/{image}",
                        arguments = listOf(
                            navArgument("title") { type = NavType.StringType },
                            navArgument("description") { type = NavType.StringType },
                            navArgument("frase") { type = NavType.StringType },
                            navArgument("image") { type = NavType.IntType }
                        )
                    ) { item ->
                        val title = item.arguments?.getString("title") ?: ""
                        val description = item.arguments?.getString("description") ?: ""
                        val frase = item.arguments?.getString("frase") ?: ""
                        val image = item.arguments?.getInt("image") ?: 0
                        DetailScreen(title, description, image, frase)
                    }
                }
            }
        }
    }
}

@Composable
fun ItemList(navController: NavController) {
    val dataList = Datos.sampleItems()
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        items(dataList.size) { index ->
            DataLazyRow(items = dataList[index], navController)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}


@Composable
fun DataLazyRow(items: Datos, navController: NavController) {
    Card(
        modifier = Modifier
            .width(300.dp)
            .height(100.dp)
            .clickable {
                val encodedTitle = Uri.encode(items.title)
                val encodedDescription = Uri.encode(items.description)
                val encodedFrase = Uri.encode(items.frase)
                navController.navigate("detail/$encodedTitle/$encodedDescription/$encodedFrase/${items.image}")
            },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row {
            Image(
                modifier = Modifier
                    .width(100.dp)
                    .height(100.dp),
                painter = painterResource(id = items.image),
                contentDescription = null
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = items.title, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = items.frase, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}



