package com.example.arrayrecu.data

import com.example.arrayrecu.R


data class Datos(val title: String, val frase: String, val description: String, val image: Int) {
    companion object {
        fun sampleItems() = listOf(
            Datos("1", "soy el 1", "Numero Uno, alias PrimeroCagon es el primer numero. Le gusta el gazpacho y el Need For Speed aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",R.drawable.uno),
            Datos("2", "soy el 2", "Numero Dos alias SegundoCampeon es el segundo numero. Disfruta del furbo y es algo tontoa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", R.drawable.dos),
            Datos("3", "soy el 3", "Numero Tres tambien conocido como TerceroPistolero es el terccero en la lista. Su principal aficion escreerse guay y el Western aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",R.drawable.tres),
            Datos("4", "soy el 4","Numero Cuatro es llamado CuartoLagarto por que es un friki otaku y huele peste. Su anime fav de chico era SAO y ahora es Solo Leveling aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", R.drawable.cuatro),
            Datos("5", "soy el 5", "Numero Cinco es el QuintoLaberinto por que vive en un laberinto y protege un poderoso tesoro. Desde direccion no tenemos ni idea de como ha llegado a esa situacion aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",R.drawable.cinco)
        )

    }
}
